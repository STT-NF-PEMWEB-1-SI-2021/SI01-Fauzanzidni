<?php

class daftar extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('model_daftar');
    }
    public function index(){
        $queryMhs['daftar'] =  $this->model_daftar->getalldaftar();
        $DATA = array('queryMhs' => $queryMhs);
        $this->load->view('daftar');
    }
    public function tambah(){
        $this->load->view('tambah');
    }
    public function input(){
        $nim = $this ->input->post('nim');
        $nama = $this ->input->post('nama');
        $matakuliah = $this ->input->post('matakuliah');
        $semester = $this ->input->post('semester');
        
        $DataInsert = array(
            'nim' => $nim,
            'nama' => $nama,
            'matakuliah' => $matakulia,
            'semester' => $semester,
    );

        $this->Model_daftar-> InserData($DataInsert);
        redirect (base_url('daftar'));
    }
} 
?>