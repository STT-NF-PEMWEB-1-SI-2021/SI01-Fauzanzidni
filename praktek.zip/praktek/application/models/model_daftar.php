<?php

class model_daftar extends CI_model{
    public function getAlldaftar(){
        $this->db->select('*');
        $this->db->from('dosen');
        $query = $this->db->get();
        return $query->result();
    }
}
?>