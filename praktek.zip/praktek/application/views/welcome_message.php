<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Selamat datang</title>

</head>
<body>

<div id="container">
	<h1>Selamat Datang</h1>

	<div id="body">
		<p>	Jangan Lupa Berdoa Sebelum Belajar</p>
	</div>

	
</div>

</body>
</html>
