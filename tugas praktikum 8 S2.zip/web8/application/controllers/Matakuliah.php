<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matakuliah extends CI_Controller {

    public function index()
    {
        $this->load->model('Matakuliah_model','mk1');
        $this->mk1->nama="JARINGAN KOMUNIKASI";
        $this->mk1->sks=3;
        $this->mk1->kode='01';

        $this->load->model('Matakuliah_model','mk2');
        $this->mk2->nama="UI/UX";
        $this->mk2->sks=3;
        $this->mk2->kode='02';

        $this->load->model('Matakuliah_model','mk3');
        $this->mk3->nama="Basis Data";
        $this->mk3->sks=4;
        $this->mk3->kode='03';

        $this->load->model('Matakuliah_model','mk4');
        $this->mk4->nama="PKN";
        $this->mk4->sks=3;
        $this->mk4->kode='04';

        $this->load->model('Matakuliah_model','mk5');
        $this->mk5->nama="Bahasa Inggris ";
        $this->mk5->sks=3;
        $this->mk5->kode='05';

        $this->load->model('Matakuliah_model','mk6');
        $this->mk6->nama="Pemrograman Web 2 ";
        $this->mk6->sks=4;
        $this->mk6->kode='06';

        $this->load->model('Matakuliah_model','mk7');
        $this->mk7->nama="Statistika";
        $this->mk7->sks=2;
        $this->mk7->kode='07';

      


        $list_mk = [$this->mk1, $this->mk2, $this->mk3, $this->mk4, $this->mk5, $this->mk6, $this->mk7];
        $data['list_mk']=$list_mk;
     
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('matakuliah/index',$data);
        $this->load->view('layout/footer');

    }
    public function create(){
        $data['jdl']='Form Kelola Matakuliah';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('matakuliah/create',$data);
        $this->load->view('layout/footer');

    }

    public function save(){
        $this->load->model('matakuliah_model','mk1');

        $this->mk1->nama = $this->input->post('nama');
        $this->mk1->sks = $this->input->post('sks');
        $this->mk1->kode = $this->input->post('kode');

        //die(print_r($this->mhs1));
        $data['mk1']=$this->mk1;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('matakuliah/view',$data);
        $this->load->view('layout/footer');

    }

}
?>