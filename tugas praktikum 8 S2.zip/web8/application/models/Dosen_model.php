<?php
class Dosen_model extends CI_Model{
    public $nama;
    public $nidn;
    public $pendidikan;

}
?>